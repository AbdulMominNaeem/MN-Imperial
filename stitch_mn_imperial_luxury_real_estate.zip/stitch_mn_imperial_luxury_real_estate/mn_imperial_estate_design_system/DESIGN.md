---
name: MN Imperial Estate Design System
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#4e453a'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#807569'
  outline-variant: '#d1c5b6'
  surface-tint: '#775928'
  primary: '#775928'
  on-primary: '#ffffff'
  primary-container: '#b08d57'
  on-primary-container: '#3d2700'
  inverse-primary: '#e8c086'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#615e5a'
  on-tertiary: '#ffffff'
  tertiary-container: '#96928e'
  on-tertiary-container: '#2d2b28'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdeae'
  primary-fixed-dim: '#e8c086'
  on-primary-fixed: '#281800'
  on-primary-fixed-variant: '#5d4213'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e7e2dc'
  tertiary-fixed-dim: '#cac6c1'
  on-tertiary-fixed: '#1d1b18'
  on-tertiary-fixed-variant: '#494643'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: 0em
  title:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.06em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 5rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system embodies the concept of "Quiet Luxury" tailored specifically for premier ultra-luxury residential properties, architectural villas, and historic estates across Lahore's most prestigious enclaves (DHA Phase V–VIII, Gulberg, Bahria Town, and Lake City). The brand communicates understated authority, architectural pedigree, discretion, and timeless exclusivity—echoing international standards set by luxury institutions such as Sotheby’s International Realty and Knight Frank, while retaining local cultural resonance and warmth.

### Visual Style
- **Aesthetic Movement:** Editorial Minimalism meets Classical Architectural Precision.
- **Atmosphere:** Serene, deliberate, and expansive. The visual tempo is unhurried, relying on generous negative space, strict geometric alignments, and balanced typographic tension between classic editorial serifs and functional modernist sans-serifs.
- **Imagery Art Direction:** Architectural imagery takes center stage with museum-grade framing. Photography highlights tactile materials—travertine stone, raw textured concrete, teak screens, and warm Pakistani daylight. Images are cropped into rigid rectangular aspect ratios (16:9, 4:3, or 1:1) framed with delicate hairline strokes, never overlaid with dense gradients or loud floating badges.
- **Emotional Response:** Confidence, discretion, quiet opulence, and architectural clarity. The user should feel as though they are browsing a bespoke architectural monograph rather than a transactional real estate platform.

## Colors

The color palette is deliberately restrained, drawing from natural stone, aged parchment, and subtle brass accents. It completely eschews bright saturated neons, saturated dropshadows, or heavy fills.

### Palette Application
- **Primary Canvas Background (`#F7F5F2`):** A warm off-white that prevents screen glare and evokes archival museum paper.
- **Elevated Surfaces (`#FFFFFF` & `#F2EFEA`):** Pure white is reserved for high-focus inspection cards, interactive sheets, and photo backdrops. Warm cream (`#F2EFEA`) is applied to nested content blocks, filter bars, and alternating catalog stripes.
- **Charcoal Primary Ink (`#1C1C1C`):** Used for titles, primary headings, key data points, and assertive UI states. Ensures AAA contrast against off-white backgrounds without the harsh synthetic severity of pure black (`#000000`).
- **Muted Secondary Ink (`#6E6B67`):** Applied to editorial secondary copy, metadata (sq. ft, bed/bath counts, enclave tags), and structural labels.
- **Soft Gold Accent (`#B08D57`):** A brushed antique bronze/gold, applied with strict moderation. Reserved for primary booking CTAs, active pagination states, VIP verification badges, fine hairline rule dividers, and bespoke architectural icons.
- **Structural Border Line (`#E5E1DA`):** A neutral, warm hairline tone that establishes visual structure without visual clutter.

## Typography

The typographic hierarchy establishes an editorial cadence reminiscent of luxury broadsheets and fine architectural monographs.

- **Headlines (`Playfair Display`):** Carries the emotional weight of heritage, high design, and exclusivity. Set with disciplined, slightly negative tracking at large display scales and moderate letter-spacing for smaller titles to ensure high-contrast serifs remain legible and sophisticated.
- **Body & Controls (`Plus Jakarta Sans`):** Selected for its crisp geometric proportion and humanist warmth. It delivers high optical legibility across property specs, investment schedules, and technical floorplans.
- **Editorial Sub-headers & Micro-labels:** Captions, status badges, currency indicators (e.g., `PKR 450,000,000`), and category metadata utilize uppercase `Plus Jakarta Sans` with expanded tracking (`0.08em` to `0.12em`) to ground the layout with architectural precision.

## Layout & Spacing

The layout philosophy follows a disciplined, gallery-grade structural grid that emphasizes symmetry, balance, and intentional rhythm.

### Grid Architecture
- **Desktop (1200px+):** 12-column fluid grid framed within a maximum container width of `1440px`. Gutters sit at `2.5rem` (`40px`), with generous outer margins of `5rem` (`80px`) to preserve a curated catalog feel.
- **Tablet (768px - 1199px):** 8-column grid with `1.5rem` (`24px`) gutters and `2.5rem` (`40px`) margins.
- **Mobile (320px - 767px):** 4-column layout with `1rem` (`16px`) gutters and `1.25rem` (`20px`) margins.

### Spatial Discipline
- Spacing between disparate editorial sections should be deliberate and expansive (`space-xl` or larger), giving high-value properties the isolation required to convey uniqueness.
- Internal component rhythm follows an 8-point baseline scale. Compact density modes are prohibited; all text and media modules require open breathing room to maintain the quiet luxury aesthetic.

## Elevation & Depth

To remain true to the "Quiet Luxury" philosophy, elevation relies almost exclusively on flat, disciplined planes, tonal layering, and razor-sharp architectural outlines rather than volumetric shadows.

### Elevation Principles
- **No Heavy Shadows:** Blurry drop shadows, colored ambient glows, and skeuomorphic extrusions are strictly prohibited.
- **Hairline Framing:** Visual separation and structure are achieved via 1px solid hairline borders in `#E5E1DA`. This draws inspiration from physical architectural blueprints and gallery framing.
- **Tonal Tiers:**
  - *Base Layer:* The viewport canvas is `#F7F5F2`.
  - *Surface Tier 1 (Cards, Property Panels, Navbars):* Pure `#FFFFFF` or `#F2EFEA`, framed by a single 1px hairline border.
  - *Surface Tier 2 (Floating Popovers, Filter Drawers, VIP Inquiry Sheets):* Crisp `#FFFFFF` with a 1px `#E5E1DA` border, accompanied by an extremely faint, architectural whisper shadow: `0 8px 32px rgba(28, 28, 28, 0.04)`.
- **Backdrop Blurs:** When sheets or modal dialogs appear, the background dims via `#1C1C1C` at an ultra-low `16%` opacity coupled with a subtle `8px` backdrop blur to keep the focus sharp and refined.

## Shapes

The design system employs a nearly sharp architectural profile. Geometry reflects modern luxury villas with clean parapet lines, steel framing, and precision-cut stone.

### Radius System
- **Base Components (`0.25rem` / `4px`):** Buttons, form inputs, badge containers, and interactive chips use a subtle 4px radius. It softens the interface slightly without losing crisp structural geometry.
- **Property Image Framing (`0.125rem` to `0.25rem` / `2px` to `4px`):** Architecture photography containers remain razor-sharp or feature a maximum of 2px–4px radius to simulate fine-art prints.
- **Containers & Panels (`0.5rem` / `8px`):** Modals, full-screen gallery viewports, and property sheets use `rounded-lg` (8px), maintaining clean planar geometry.
- **Circular Elements:** Reserved solely for icon-only action triggers (e.g., circular photo sliders, gallery zoom anchors, and audio tour toggles).

## Components

### Buttons
- **Primary (Private Viewing / Inquire):** Solid soft gold (`#B08D57`) background with charcoal or white typography, subtle 4px corner radius, and 1px matching gold border. On hover, the gold slightly warms (`#A3804C`) with a crisp micro-lift.
- **Secondary (Editorial Outline):** Transparent background, 1px solid `#1C1C1C` or `#E5E1DA`, charcoal text (`#1C1C1C`). On hover, transitions smoothly to a solid `#1C1C1C` fill with white text.
- **Text / Link Button:** Pure charcoal or muted gold typography with an animated hairline underline (`1px solid #B08D57`) that expands from left to right on hover.

### Property Cards (Catalog Aesthetic)
- **Container:** Pure `#FFFFFF` surface with a crisp 1px `#E5E1DA` outer hairline. Zero shadows.
- **Image Module:** Fixed aspect ratio (`4:3` or `16:9`) with a discreet gold-accented enclave badge in the top-left (e.g., `GULBERG V`, `DHA PHASE VI`).
- **Typography Layout:** Property title set in `Playfair Display` (`headline-sm`), followed by a subtle 1px divider, ending with specs (Beds, Baths, Marla / Kanal measurements) formatted in tracked uppercase `Plus Jakarta Sans` (`label-md`).

### Form Fields & Inputs
- **Text Inputs:** Pristine `#FFFFFF` or `#F2EFEA` background, 1px `#E5E1DA` border, 4px radius, padded with `space-sm` vertically and `space-md` horizontally.
- **Focus State:** Hairline border transitions precisely to soft gold (`#B08D57`). No glowing rings or thick halos.
- **Floating Labels:** Formatted in uppercase `Plus Jakarta Sans` (`label-sm`), styled in muted charcoal (`#6E6B67`).

### Badges & Chips
- **Enclave & Status Indicators:** Soft tinted cream background (`#F2EFEA`) with a 1px hairline border (`#E5E1DA`) and dark charcoal typography (`label-sm`).
- **Exclusive / Off-Market Flag:** Soft gold border (`#B08D57`) with warm gold lettering on a transparent background, signaling discreet VIP offerings.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes:** Square with a 2px radius, 1px `#E5E1DA` border. When selected, fills with solid `#1C1C1C` or `#B08D57` containing a crisp 1.5px white hairline checkmark.
- **Radio Buttons:** Clean concentric circles with a 1px border. Selected state houses a centered dot in `#B08D57`.

### Bespoke Domain Components
- **Architectural Specification Bar:** A horizontal strip displaying structural specifics (Plot Area in Kanals/Marlas, Covered Area, Architect Name, Year Completed) separated by 1px vertical hairline dividers in `#E5E1DA`.
- **Private Concierge Dock:** A persistent, minimal contact dock set at the base of property listings, featuring direct WhatsApp and Private Office inquiry triggers rendered in refined hairline styling.